﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;

namespace BTVN2
{
    internal class PhanSo
    {
        ArrayList list = new ArrayList();
        private int tuSo;
        private int mauSo;

        public PhanSo()
        {

        }
        public PhanSo(int tuSo, int mauSo)
        {
            this.tuSo = tuSo;
            this.mauSo = mauSo == 0 ? 1 : mauSo;
        }
        public void NhapPhanSo()
        {
            PhanSo phanSo = new PhanSo();
            Console.Write("nhap tu so: ");
            phanSo.tuSo = int.Parse(Console.ReadLine() ?? "0");
            Console.Write("nhap mau so: ");
            phanSo.mauSo = int.Parse(Console.ReadLine() ?? "0");
            if (phanSo.mauSo == 0)
            {
                Console.WriteLine("mau khong duoc bang 0.");
                phanSo.mauSo = 1;
            }
            list.Add(phanSo);
        }
        public void HienThiPS()
        {
            foreach (object item in list)
            {
                if (item is PhanSo ps)
                {
                    PhanSo PS = (PhanSo)item;
                    Console.WriteLine(ps.tuSo + "/" + ps.mauSo);
                }
               
            }
        }

        public int gcd(int tu, int mau)
        {
            while (mau != 0)
            {
                int temp = tu % mau;
                tu = mau;
                mau = temp;
            }
            return Math.Abs(tu);
        }

        public void rutGon(int tu, int mau, int UC)
        {
            int tuRG = tu / UC;
            int mauRG = mau / UC;
            Console.WriteLine($"{tuRG}/{mauRG}");
        }

        public void Cong2PS()
        {
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine($"nhap phan so thu {i + 1}");
                NhapPhanSo();
            }
             
            PhanSo PS1 = (PhanSo)list[0];
            PhanSo PS2 = (PhanSo)list[1];
            
            int tuMoi = PS1.tuSo*PS2.mauSo + PS2.tuSo*PS1.mauSo;
            int mauMoi = PS1.mauSo * PS2.mauSo;

            Console.WriteLine($"{tuMoi}/{mauMoi}");
            int UC = gcd(tuMoi, mauMoi);
            Console.WriteLine("uoc chung" + UC);
            rutGon(tuMoi, mauMoi, UC);
        }
        public void CongNhieuPS()
        {
            Console.Write("nhap phan so can cong: ");
            int soLuong = int.Parse(Console.ReadLine() ?? "0");

            for (int i = 0; i < soLuong; i++)
            {
                Console.WriteLine($"nhap phan so can cong {i + 1}:");
                NhapPhanSo();
            }

            if (list.Count == 0) return;

            PhanSo tong = (PhanSo)list[0];

            for (int i = 1; i < list.Count; i++)
            {
                PhanSo hienTai = (PhanSo)list[i];
                int tuMoi = tong.tuSo * hienTai.mauSo + hienTai.tuSo * tong.mauSo;
                int mauMoi = tong.mauSo * hienTai.mauSo;

                tong = new PhanSo(tuMoi, mauMoi);
            }

            int UC = gcd(tong.tuSo, tong.mauSo);
            rutGon(tong.tuSo, tong.mauSo, UC);
        }


    }
}
