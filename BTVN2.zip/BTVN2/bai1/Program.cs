﻿using BTVN2;


PhanSo ps = new PhanSo();
Console.WriteLine("chon phuong thuc: ");
Console.WriteLine("1. nhap phan so");
Console.WriteLine("2. cong phan so");
Console.WriteLine("3. cong tat ca phan so co trong list");
while (true)
{
    char c = char.Parse(Console.ReadLine() ?? "0");
    switch (c)
    {
        case '1':
            ps.NhapPhanSo();
            break;
        case '2':
            ps.Cong2PS();
            break;
        case '3':
            ps.CongNhieuPS();
            break;
        default:
            break;
    }
    Console.WriteLine("ban co muon tiep tuc khong??");
    Console.WriteLine("chon 'N' de thoat");
    char thoat = char.Parse(Console.ReadLine() ?? "0");
    if (thoat == 'N' || thoat == 'n')
    {
        break;
    }
}


