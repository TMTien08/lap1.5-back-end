﻿using System;
using System.Collections;
using bai2;


Console.OutputEncoding = System.Text.Encoding.UTF8;
ArrayList list = new ArrayList();

while (true)
{
    Console.WriteLine("\nMENU:");
    Console.WriteLine("1. Hình chữ nhật");
    Console.WriteLine("2. Hình vuông");
    Console.WriteLine("3. Hình tam giác");
    Console.WriteLine("4. Hình tròn");
    Console.WriteLine("Chọn loại hình (1-4): ");
    char c = char.Parse(Console.ReadLine() ?? "0");

    Hinh hinh = null;

    switch (c)
    {
        case '1':
            HinhChuNhat hcn = new HinhChuNhat();
            Console.Write("Nhập chiều dài: ");
            hcn.Dai = double.Parse(Console.ReadLine() ?? "0");
            Console.Write("Nhập chiều rộng: ");
            hcn.Rong = double.Parse(Console.ReadLine() ?? "0");
            hinh = hcn;
            break;

        case '2':
            HinhVuong hv = new HinhVuong();
            Console.Write("Nhập cạnh: ");
            hv.canh = double.Parse(Console.ReadLine() ?? "0");
            hinh = hv;
            break;

        case '3':
            HinhTamGiac htg = new HinhTamGiac();
            Console.Write("Nhập cạnh a: ");
            htg.A = double.Parse(Console.ReadLine() ?? "0");
            Console.Write("Nhập cạnh b: ");
            htg.B = double.Parse(Console.ReadLine() ?? "0");
            Console.Write("Nhập cạnh c: ");
            htg.C = double.Parse(Console.ReadLine() ?? "0");
            hinh = htg;
            break;

        case '4':
            HinhTron ht = new HinhTron();
            Console.Write("Nhập bán kính: ");
            ht.BanKinh = double.Parse(Console.ReadLine() ?? "0");
            hinh = ht;
            break;

        default:
            Console.WriteLine("Không có lựa chọn này!");
            break;
    }

    if (hinh != null)
    {
        Console.WriteLine($"→ Chu vi: {hinh.ChuVi():F2}");
        Console.WriteLine($"→ Diện tích: {hinh.DienTich():F2}");
        list.Add(hinh);
    }

    Console.WriteLine("\nBạn có muốn tiếp tục? (N để thoát): ");
    char thoat = char.Parse(Console.ReadLine() ?? "0");
    if (thoat == 'N' || thoat == 'n') break;
}

// Tính tổng
double tongCV = 0, tongDT = 0;
foreach (Hinh h in list)
{
    tongCV += h.ChuVi();
    tongDT += h.DienTich();
}

Console.WriteLine($"\n>>> Tổng chu vi: {tongCV:F2}");
Console.WriteLine($">>> Tổng diện tích: {tongDT:F2}");
    