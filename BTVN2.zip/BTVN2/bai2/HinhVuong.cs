﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    internal class HinhVuong : Hinh
    {
        public double canh { get; set; }

        public HinhVuong()
        {
        }

        public HinhVuong(double canh)
        {
            this.canh = canh;
        }

        public override double ChuVi()
        {
            return 4 * canh;
        }

        public override double DienTich()
        {
            return canh * canh;
        }
    }
}

