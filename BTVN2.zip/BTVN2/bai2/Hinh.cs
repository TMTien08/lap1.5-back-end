﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    public abstract class Hinh
    {
        public abstract double ChuVi();
        public abstract double DienTich();
    }
}

